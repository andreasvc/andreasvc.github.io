import re
from glob import glob
from lxml import html
from tqdm import tqdm


def trivialteireader(fname):
    """Extremely simplistic TEI reader. Avoids lxml overhead."""
    with open(fname) as inp:
        tei = inp.read()
    text = re.sub(r'<.*?>', '', tei[tei.index('<body'):], flags=re.DOTALL)
    return text


# def readtext(fname):
#     """Read text in TEI format and return plain text.
# 
#     :param fname: filename of a TEI-XML file.
#     :returns: plain text string."""
#     doc = html.parse(fname)
#     body = doc.getroot().find('./body')
#     ...


for fname in tqdm(glob('*.xml')):
    print(fname)
    text = trivialteireader(fname)
    with open(fname.replace('.xml', '.txt'), 'w') as out:
        out.write(text)
